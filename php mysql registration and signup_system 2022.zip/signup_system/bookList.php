<?php
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h1>Your Email Id : $_SESSION[email]</h1>");
} else{
    header('Location: login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book List</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="bookList.css">
</head>
<body>

    <div class="container">

        <div id="topTitleDiv">
        <img src="img/Hydrangeas.jpg" alt="Pic"/>
        <span>User Name : MD.MITHUN MIAH > Business : DEVELOPMENT DESIGN CONSULTANTS LTD. >>> Module : DDC Library</span>
        <a href="mainWindow.php" class="btnHome"><i class="fa-solid fa-house"></i></a> 
        <a href="logout.php" class="btnClose"><i class="fa-solid fa-square-xmark"></i></a>
        </div>
        <hr/>
    
        <div id="topManuDiv">

            <div class="dropdown">
                <button onclick="myFunction()" class="dropbtn">Entry Menu</button>
                <div id="myDropdown" class="dropdown-content">
                  <a href="bookEntry.php">Book Entry</a>
                  <a href="authorEntry.php">Author Entry</a>
                  <a href="publisherEntry.php">Publisher Entry</a>
                </div>
    
                <button onclick="myFunctionRepo()" class="dropbtn">Reports</button>
                <div id="myDropdownRepo" class="dropdown-content">
                  <a href="#">Book List</a>
                </div>
                
              </div>
    
        </div>
    
        <div id="btnCheckbox">
        <label> Book Entry </label> 
        <input type="checkbox"/>
        </div>
    
        <section id="formSection">
    
        <div class="sideL">
            <p>Book List</p>
            <form action="">
                <label for="">Select Report :</label>
                <select name="" id="book-list">
                    <option value="">Book List</option>
                </select>
                <br>
                <label for="">Book ID/Accession No.:</label>
                <input type="text" id="book-id"></input>
                <a href="#" id="bookIdSearch">Search</a>
                <br>
                <label for="">Author :</label>
                <input type="text" id="author-id"></input>
                <a href="#" id="bookIdSearch">Search</a>
                <br>
                <label for="">Co Author :</label>
                <input type="text" id="co-author-id"></input>
                <!-- <a href="#" id="authorIdSearch">Search</a>
                <input type="text" id="authorIdDisabled" disabled> -->
                <br>
                <label for="">Category :</label>
                <!-- <input type="number" id="category"></input> -->
                <select name="" id="category">
                    <option value=""></option>
                    <option value="">Engineering</option>
                    <option value="">History</option>
                    <option value="">Agriculture</option>
                    <option value="">Science</option>
                    <option value="">Technology</option>
                </select>
                <br>
                <label for="">Sub Category :</label>
                <!-- <input type="number" id="sub-category"></input> -->
                <select name="" id="sub-category">
                    <option value=""></option>
                    <option value="">Civil Engineering</option>
                    <option value="">BangladeshHistory</option>
                    <option value="">Crops and Cron</option>
                    <option value="">Invention</option>
                    <option value="">Computer</option>
                </select>
                <br>
                <label for="">Books Location :</label>
                <!-- <input type="number" id="book-location"></input> -->
                <select name="" id="book-location">
                    <option value=""></option>
                    <option value="">DDC Centre</option>
                    <option value="">Matikata</option>
                </select>
                <br>
                <label for="">Shelf No. :</label>
                <!-- <input type="number" id="shelf-no"></input> -->
                <select name="" id="shelf-no">
                    <option value=""></option>
                    <option value="">gs-1/ss-1/s-1</option>
                    <option value="">gs-2/ss-2/s-2</option>
                    <option value="">gs-3/ss-3/s-3</option>
                    <option value="">gs-4/ss-4/s-4</option>
                </select>
                <br>
                <label for="">Usage Type :</label>
                <select name="" id="usage-type">
                    <option value=""></option>
                    <option value="">General</option>
                    <option value="">Reference</option>
                </select>
                <br>
                <label for="">Publisher :</label>
                <input type="text" id="publisher">
                <a href="#" id="bookIdSearch">Search</a>
                <br>
                <label for="">Language :</label>
                <select name="" id="language">
                    <option value=""></option>
                    <option value="">Bengali</option>
                    <option value="">English</option>
                    <option value="">Arabic</option>
                    <option value="">Russian</option>
                </select>
                <br>
                <label for="">Cover :</label>
                <select name="" id="cover">
                    <option value=""></option>
                    <option value="">Hard</option>
                    <option value="">Soft</option>
                    <option value="">Thin</option>
                </select>
                <br>
                <label for="">Print Paper :</label>
                <select name="" id="print-paper">
                    <option value=""></option>
                    <option value="">Offset</option>
                    <option value="">Newsprint</option>
                    <option value="">Glossy</option>
                    <option value="">Photo</option>
                </select>
                <br>
                <label for="">Status :</label>
                <select name="" id="status">
                    <option value=""></option>
                    <option value="">Available</option>
                    <option value="">Issued</option>
                    <option value="">Damaged</option>
                    <option value="">Lost</option>
                </select>
                <br>
                <label for="">Between :</label>
                <select name="" id="between">
                    <option value=""></option>
                    <option value="">Book Title</option>
                    <option value="">Keyword</option>
                    <option value="">Subject</option>
                    <option value="">Language</option>
                </select>
                <br>
                <label for="">Like :</label>
                <input type="text" id="total-pages-id" value=""></input>
            </form>
            <hr>
            <div class="bookListBtnDiv">
                <button id="bookListReport"><a href="#">Show Report</a></button>
            </div>
            <div class="styleBottom"></div>
        </div>

        </section>
    
        <div id="footerDiv">
            <p>Powered by Me</p>
        </div>
    
        </div>
    

        <script>
            /* When the user clicks on the button, 
            toggle between hiding and showing the dropdown content */
            function myFunction() {
              document.getElementById("myDropdown").classList.toggle("show");
            }
    
            function myFunctionRepo() {
              document.getElementById("myDropdownRepo").classList.toggle("show");
            }
    
            window.onclick = function(event) {
              if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) {
                  var openDropdown = dropdowns[i];
                  if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                  }
                }
              }
            }
            
            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
              if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) {
                  var openDropdown = dropdowns[i];
                  if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                  }
                }
              }
            }
    
            
        </script>
</body>
</html>