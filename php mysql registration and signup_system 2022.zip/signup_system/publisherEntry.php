<?php
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h1>Your Email Id : $_SESSION[email]</h1>");
} else{
    header('Location: login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publisher Entry</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="publisherEntry.css">

    <style>
      #searchBar {
        width: 100%;
        height: 50px;
        font-size: 17px;
        margin-top: 0px;
        outline: none;
        border-radius: 5px;
        padding: 5px;
        background-color: aliceblue;
      }
      /* Form Input Section Left Side */
      .sideL {
        width: 100%;
        padding: 10px 5px;
        margin: auto;
        border: 1px solid red;
      }
      .sideL form label {
        width: 170px;
        display: inline-block;
        text-align: start;
        color: #fff;
      }
      .sideL form input {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }

      #author-name,
      #prefix-id,
      #print-paper,
      #cover,
      #language,
      #country-id,
      #usage-type,
      #between,
      #status {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #author-id {
        width: 180px;
        height: 35px;
      }
      #contactNumber-id {
        width: 150px;
        height: 35px;
      }
      #citizen-id {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      .remarks-div {
        display: flex;
        align-items: center;
        margin-bottom: 5px;
      }
      #remarks-id {
        border-radius: 5px;
        display: inline;
        width: 250px;
        height: 35px;
        margin-left: 5px;
      }
      #enteredName-id {
        width: 150px;
        height: 35px;
      }
      #updatedName-id {
        width: 150px;
        height: 35px;
      }

      #authorIdSearch {
        color: #fff;
        background-color: rgb(50, 50, 197);
        padding: 5px;
        border-radius: 10px;
        font-size: 14px;
        letter-spacing: 0.7px;
      }
    </style>
</head>
<body>

    <div class="container">

        <div id="topTitleDiv">
        <img src="img/Hydrangeas.jpg" alt="Pic"/>
        <span>User Name : MD.MITHUN MIAH > Business : DEVELOPMENT DESIGN CONSULTANTS LTD. >>> Module : DDC Library</span>
        <a href="mainWindow.php" class="btnHome"><i class="fa-solid fa-house"></i></a> 
        <a href="logout.php" class="btnClose"><i class="fa-solid fa-square-xmark"></i></a>
        </div>
        <hr/>
    
        <div id="topManuDiv">

            <div class="dropdown">
                <button onclick="myFunction()" class="dropbtn">Entry Menu</button>
                <div id="myDropdown" class="dropdown-content">
                  <a href="bookEntry.php">Book Entry</a>
                  <a href="authorEntry.php">Author Entry</a>
                  <a href="#">Publisher Entry</a>
                </div>
    
                <button onclick="myFunctionRepo()" class="dropbtn">Reports</button>
                <div id="myDropdownRepo" class="dropdown-content">
                  <a href="bookList.php">Book List</a>
                </div>
                
              </div>
    
        </div>
    
        <div id="btnCheckbox">
        <label> Book Entry </label> 
        <input type="checkbox"/>
        </div>
    
        <section id="formSection">
    
        <div class="sideL">
            <div class="authorEntryBtnDiv">
                <button id="author-add-btn"><a href="#">Add</a></button>
                <button id="author-update-btn"><a href="#">Update</a></button>
                <button id="author-clear-btn"><a href="#">Clear</a></button>
            </div>
            <hr>
            <form action="">
                <label for="">ID Prefix :</label>
                <select name="" id="prefix-id">
                    <option value="">----Select Prefix----</option>
                    <option value="">PUB :-</option>
                </select>
                <br>
                <label for="">Publisher ID :</label>
                <input type="text" id="author-id"></input>
                <a href="#" id="authorIdSearch">Search</a>
                <br>
                <label for="">Publisher Name :</label>
                <input type="text" id="author-name"></input>
                <br>
                <label for="">Company :</label>
                <input type="text" id="organization-id"></input>
                <br>
                <label for="">Contact No. :</label>
                <input type="number" id="contactNumber-id"></input>
                <br>
                <label for="">Country :</label>
                <select name="" id="country-id">
                    <option value="">--Select--</option>
                    <option value="">Bangladesh</option>
                    <option value="">India</option>
                    <option value="">Japan</option>
                    <option value="">Korea</option>
                    <option value="">America</option>
                </select>
                <br>
                <label for="">Email :</label>
                <input type="text" id="email-id"></input>
                <br>
                <label for="">Web :</label>
                <select name="" id="citizen-id">
                    <option value="">--Select--</option>
                </select>
                <br>
                <div class="remarks-div">
                    <label for="">Remarks :</label>
                    <textarea name="" id="remarks-id" cols="30" rows="3"></textarea>
                </div>
                <label for="">Entered By :</label>
                <input type="text" id="enteredName-id" disabled>
                <br>
                <label for="">Updated By :</label>
                <input type="text" id="updatedName-id" disabled>
                <br><br>
            </form>
        </div>
        <div class="showAuthorListDiv">
            <p>Total Publisher: 1885</p>
            <input type="search" placeholder="Search By Publisher ID, Publisher Name, Organization, Contact No..." id="searchBar">
            <div>
                <h3>This division for show Publisher data dynamically</h3>
            </div>
        </div>


        </section>
    
        <div id="footerDiv">
            <p>Powered by Me</p>
        </div>
    
        </div>
    
        <script>
            /* When the user clicks on the button, 
            toggle between hiding and showing the dropdown content */
            function myFunction() {
              document.getElementById("myDropdown").classList.toggle("show");
            }
    
            function myFunctionRepo() {
              document.getElementById("myDropdownRepo").classList.toggle("show");
            }
    
            window.onclick = function(event) {
              if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) {
                  var openDropdown = dropdowns[i];
                  if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                  }
                }
              }
            }
            
            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
              if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) {
                  var openDropdown = dropdowns[i];
                  if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                  }
                }
              }
            }
    
            
        </script>
</body>
</html>