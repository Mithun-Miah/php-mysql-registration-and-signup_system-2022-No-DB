<?php
// For Store data
session_start();
//database connection
$connection = mysqli_connect('localhost','root','','signup_db');
//database connection check
if($connection){
    echo "Connection Success";
} else{
    echo "Connection Failed";
}

//Select html form name attribute
if(isset($_POST['loginBtn'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $select = "SELECT * FROM registration_table where email = '$email' AND password = '$password' ";
    $query = mysqli_query($connection, $select);

    $fetch = mysqli_fetch_array($query);
    if($fetch){
        
        header('Location: mainWindow.php');
        // echo "<script>alert('Login Successful')</script>";
        // fetch email address from database to another page display
        $_SESSION['email'] = $fetch['email'];
        $_SESSION['first_name'] = $fetch['first_name'];

    }else{
        echo "<script>alert('Email and Password Not Matched')</script>";
    }
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login Form</title>
    <link rel="stylesheet" href="login.css">

    <style>
        .loginDiv {
            text-align: center;
            margin-right: 185px;
            margin-bottom: 60px;
        }
        .btnDiv {
            text-align: center;
            margin-top: auto;
            padding-right: 100px;
        }
    </style>
</head>
<body>

<div class="reg_container">
        <h1>Login</h1>
        <form method="POST">
            <label for="">Email</label>
            <br>
            <input type="text" name="email" require>
            <br><br>
            <label for="">Password</label>
            <br>
            <input type="password" name="password" require>
            <br><br>
            <div class="loginDiv">
            <button id="logBtn" name="loginBtn">Login</button>
            </div>
        </form>
        <div class="btnDiv">
        
        <a href="registration.php" id="regBtn">Create Account</a>
        </div>
    </div>
    
</body>
</html>