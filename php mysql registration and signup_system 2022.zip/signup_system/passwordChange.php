<?php
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h1>Your Email Id : $_SESSION[email]</h1>");
} else{
    header('Location: login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Change</title>
    <link rel="stylesheet" href="passwordChange.css">
</head>
<body>

    <section class="wrapper">
        <div class="container">
            <div class="centerContent">
                <div class="logo">
                    <a href="#"><img src="img/logo.png" class="image-fluid" alt="logo"></a>
                </div>
                <form class="rounded bg-white shadow p-5" action="">
                    <p class="text-dark fw-bolder fs-4 mb-2">Please Login To Your Account</p>
                    <div class="userAndStaff">
                        
                        <label for="user">
                            <input type="radio" id="user" value="" name="user"> User</label>
                        
                        <label for="staff">
                            <input type="radio" id="staff" value="" name="user"> Staff</label>
                    </div>
                    <div class="form-floating mb-3">
                        <label for="">User ID :</label>
                        <input type="text">
                        <br>
                        <label for="">User Name :</label>
                        <input type="text">
                        <br>
                        <label for="">Old Password :</label>
                        <input type="text">
                        <br>
                        <label for="">New Password :</label>
                        <input type="text">
                        <br>
                        <label for="">Confirm Password :</label>
                        <input type="text">
                    
                      </div>

                      <div class="signInBtnDiv">
                          <a href="#" class="submit-btn">Change Password</a>
                          <a href="mainWindow.php" class="submit-btn" id="backHome">Back Home</a>
                          <a href="logout.php" class="submit-btn" id="logOut">Log Out</a>
                      </div>
                      
                </form>

            </div>
            <div class="mt-2 text-end forgetPassword">
                <a href="#" class="text-primary fw-bold text-decoration-none">Forget Password?</a>
            </div>
        </div>
    </section>
    
</body>
</html>