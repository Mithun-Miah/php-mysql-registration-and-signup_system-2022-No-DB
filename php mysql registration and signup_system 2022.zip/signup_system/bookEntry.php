<?php
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h1>Your Email Id : $_SESSION[email]</h1>");
} else{
    header('Location: login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Entry</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="bookEntry.css">

    <style>
      .sideL form input {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #bookId {
        width: 150px;
        height: 35px;
      }
      #publisher-id {
        width: 90px;
        height: 35px;
      }
      #autor-id {
        width: 90px;
        height: 35px;
      }
      #authorIdDisabled {
        width: 100px;
        height: 35px;
      }
      #pubIdDisabled {
        width: 100px;
        height: 35px;
      }
      #pub-print-date-id {
        width: 90px;
        height: 35px;
      }
      #bookIdSearch {
        color: #fff;
        background-color: rgb(50, 50, 197);
        padding: 5px;
        border-radius: 10px;
        font-size: 14px;
        letter-spacing: 0.7px;
        height: 35px;
      }
      #authorIdSearch {
        color: #fff;
        background-color: rgb(50, 50, 197);
        padding: 5px;
        border-radius: 10px;
        font-size: 14px;
        letter-spacing: 0.7px;
        height: 35px;
      }
      #pubIdSearch {
        color: #fff;
        background-color: rgb(50, 50, 197);
        padding: 5px;
        border-radius: 10px;
        font-size: 14px;
        letter-spacing: 0.7px;
        height: 35px;
      }
      #print-paper {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #cover {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #language {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #category {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #sub-category {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #usage-type {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #first-edition-id {
        width: 150px;
        height: 35px;
      }
      #first-edition-date-id {
        width: 100px;
        height: 35px;
      }
      #avail-edition-id {
        width: 150px;
        height: 35px;
      }
      #avail-edition-date-id {
        width: 100px;
        height: 35px;
      }
      /* =================== */
      /* Form Input Section Right Side */
      .sideR {
        width: 100%;
        background-color: gray;
        padding: 10px 5px;
      }
      .sideR form label {
        width: 200px;
        display: inline-block;
      }
      .sideR form input {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #currency-id {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #book-location-id {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
        text-transform: uppercase;
      }
      #book-shelf-id {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
        text-transform: uppercase;
      }
      #status-id {
        margin-bottom: 5px;
        outline: none;
        border-radius: 5px;
        width: 250px;
        height: 35px;
      }
      #entry-date-id {
        width: 90px;
        height: 35px;
        outline: auto;
      }
      #check-date-id {
        width: 90px;
        height: 35px;
      }
      #member-id,
      #transaction-id,
      #issue-id,
      #return-id,
      #enter-by-id,
      #update-by-id {
        width: 90px;
        height: 35px;
        outline: auto;
      }
      /* Search Bar Section */
      #searchBar {
        width: 100%;
        margin-top: 10px;
        outline: none;
        border-radius: 5px;
        padding: 5px;
        height: 50px;
        font-size: 20px;
        background-color: aliceblue;
      }

    </style>
</head>

<body>

    <div class="container">

    <div id="topTitleDiv">
    <img src="img/Hydrangeas.jpg" alt="Pic"/>
    <span>User Name : MD.MITHUN MIAH > Business : DEVELOPMENT DESIGN CONSULTANTS LTD. >>> Module : DDC Library</span>
    <a href="mainWindow.php" class="btnHome"><i class="fa-solid fa-house"></i></a> 
    <a href="logout.php" class="btnClose"><i class="fa-solid fa-square-xmark"></i></a>
    </div>
    <hr/>

    <div id="topManuDiv">

        <div class="dropdown">
            <button onclick="myFunction()" class="dropbtn">Entry Menu</button>
            <div id="myDropdown" class="dropdown-content">
              <a href="#">Book Entry</a>
              <a href="authorEntry.php">Author Entry</a>
              <a href="publisherEntry.php">Publisher Entry</a>
            </div>

            <button onclick="myFunctionRepo()" class="dropbtn">Reports</button>
            <div id="myDropdownRepo" class="dropdown-content">
              <a href="bookList.php">Book List</a>
            </div>
            
          </div>

    </div>

    <div id="btnCheckbox">
    <label> Book Entry </label> 
    <input type="checkbox"/>
    </div>

    <div id="btnDiv">
    <button id="btnSubmit" type="submit" name="bookAdd"> Add </button>
    <button id="btnUpdate" type="submit" name="bookUpdate"> Update </button>
    <button id="btnDelete" type="submit" name="bookDelete"> Delete </button>
    <button id="btnClear" type="submit" name="ClearAllField"> Clear </button>
    <hr/>
    </div>

    <section id="formSection">

    <div class="sideL">
        <form method="POST">
            <label for="">Book ID :</label>
            <input type="text" name="bId" id="bookId">
            <a href="#" id="bookIdSearch">Search</a>
            <br>
            <label for="">Book Title :</label>
            <input type="text" name="bTitle" id="book-title"></input>
            <br>
            <label for="">Book Sub Title :</label>
            <input type="text" name="bSubTitle" id="book-sub-title"></input>
            <br>
            <label for="">Author ID :</label>
            <input type="text" name="authorId" id="autor-id"></input>
            <a href="#" name="authorIdSearch" id="authorIdSearch">Search</a>
            <input type="text" id="authorIdDisabled" disabled>
            <br>
            <label for="">Co-Author :</label>
            <input type="text" name="coAuthorId" id="co-Autor-id"></input>
            <br>
            <label for="">Editor :</label>
            <input type="text" name="editorId" id="editor-id"></input>
            <br>
            <label for="">Translator :</label>
            <input type="text" name="translatorId" id="translator-id"></input>
            <br>
            <label for="">Keyword :</label>
            <input type="text" name="keywordId" id="keyword-id"></input>
            <br>
            <label for="">Usage Type :</label>
            <select name="usageType" id="usage-type">
                <option value=""></option>
                <option value="General">General</option>
                <option value="Reference">Reference</option>
            </select>
            <br>
            <label for="">Category :</label>
            <select name="categoryId" id="category">
                <option value=""></option>
                <option value="Engineering">Engineering</option>
                <option value="History">History</option>
                <option value="Agricultur">Agricultur</option>
                <option value="Science">Science</option>
                <option value="Technology">Technology</option>
                <option value="Commerce">Commerce</option>
            </select>
            <br>
            <label for="">Sub Category :</label>
            <select name="subCategory" id="sub-category">
                <option value=""></option>
                <option value="">Civil Engineering</option>
                <option value="">Bangladesh Independent History</option>
                <option value="">Fishing</option>
                <option value="">Science Fiction</option>
            </select>
            <br>
            <label for="">Subject :</label>
            <input type="text" name="subject" id="subject-id"></input>
            <br>
            <label for="">Publisher ID :</label>
            <input type="text" name="publisherId" id="publisher-id"></input>
            <a href="#" id="pubIdSearch">Search</a>
            <input type="text" id="pubIdDisabled" disabled>
            <br>
            <label for="">Publish/Print Date :</label>
            <input type="date" name="publisherDate" id="pub-print-date-id"></input>
            <br>
            <label for="">Publish Place :</label>
            <input type="text" name="publisherPlace" id="pub-place-id"></input>
            <br>
            <label for="">First Edition & Date :</label>
            <input type="text" name="firstEdition" id="first-edition-id"></input>
            <input type="date" name="firstEditionDate" id="first-edition-date-id"></input>
            <br>
            <label for="">Available Edition & Date :</label>
            <input type="text" name="availableEdition" id="avail-edition-id"></input>
            <input type="date" name="availableEditionDate" id="avail-edition-date-id"></input>
            <br>
            <label for="">ISBN No. </label>
            <input type="text" name="isbnNo" id="isbn-id"></input>
            <br>
            <label for="">Copyright :</label>
            <input type="number" name="copyright" id="copyright-id"></input>
            <br>
            <label for="">Language :</label>
            <select name="language" id="language">
                <option value=""></option>
                <option value="">Bengali</option>
                <option value="">English</option>
                <option value="">Arabic</option>
                <option value="">Russian</option>
            </select>
            <br>
            <label for="">Consists of (Set= Vol No.) :</label>
            <input type="number" name="consistsVol" id="consists-id" value="0"></input>
            <br>
            <label for="">Total Pages :</label>
            <input type="number" name="totalPages" id="total-pages-id" value="0"></input>
            <br>
            <label for="">Cover :</label>
            <select name="cover" id="cover">
                <option value=""></option>
                <option value="">Hard</option>
                <option value="">Soft</option>
                <option value="">Thin</option>
            </select>
            <br>
            <label for="">Print Paper :</label>
            <select name="printPaper" id="print-paper">
                <option value=""></option>
                <option value="">Offset</option>
                <option value="">Newsprint</option>
                <option value="">Glossy</option>
                <option value="">Photo</option>
            </select>
        </form>
    </div>

    <div class="sideR">
        <form method="POST">
            <label for="">Purchase Date :</label>
            <input type="date" name="purchase" id="purchase-Id">
            <br>
            <label for="">Currency :</label>
            <select name="currency" id="currency-id">
                <option value=""></option>
                <option value="">BDT</option>
                <option value="">USD</option>
            </select>
            <br>
            <label for="">Purchase Price :</label>
            <input type="number" name="purchasePrice" id="purchase-price-id" value="0"></input>
            <br>
            <label for="">Exchange Rate (BDT Equ) :</label>
            <input type="number" name="exchangeRate" id="ex-rate-id" value="0"></input>
            <br>
            <label for="">Base Price :</label>
            <input type="number" name="basePrice" id="base-price-id" value="0"></input>
            <br>
            <label for="">Reference/Batch No.</label>
            <input type="text" name="refId" id="reference-id"></input>
            <br>
            <label for="">Memo/Voucher No. :</label>
            <input type="text" name="memoNo" id="memo-id"></input>
            <br>
            <label for="">Gifted By :</label>
            <input type="text" name="giftedBy" id="gift-id"></input>
            <br>
            <label for="">Email (Gifting Person) :</label>
            <input type="email" name="email" id="email-Gp-id"></input>
            <br>
            <label for="">Book Location :</label>
            <select name="bookLocation" id="book-location-id">
                <option value=""></option>
                <option value="">DDC Centre</option>
                <option value="">MATIKATA</option>
            </select>
            <br>
            <label for="">Shelf No. :</label>
            <select name="shelfNo" id="book-shelf-id">
                <option value=""></option>
                <option value="">gs-1/ss-1/s-1</option>
                <option value="">gs-2/ss-2/s-2</option>
                <option value="">gs-3/ss-3/s-3</option>
                <option value="">gs-4/ss-4/s-4</option>
            </select>
            <br>
            <label for="">Room No. :</label>
            <input type="number" name="roomNo" id="room-id" value="0"></input>
            <br>
            <label for="">Entry Date :</label>
            <input type="date" name="entryDate" id="entry-date-id" disabled></input>
            <br>
            <label for="">Checked Date :</label>
            <input type="date" name="checkDate" id="check-date-id"></input>
            <br>
            <label for="">Status :</label>
            <select name="statusId" id="status-id">
                <option value="">Available</option>
                <option value="">Issued</option>
                <option value="">Damaged</option>
                <option value="">Lost</option>
            </select>
            <br>
            <label for="">Remarks :</label>
            <input type="text" name="remarks" id="remarks-id"></input>
            <br>
            <label for="">Member ID/Employee ID :</label>
            <input type="text" name="memberId" id="member-id" disabled></input>
            <br>
            <label for="">Transaction No. :</label>
            <input type="number" name="transactionId" id="transaction-id" disabled></input>
            <br>
            <label for="">Issue Date :</label>
            <input type="date" name="issueDate" id="issue-id" disabled></input>
            <br>
            <label for="">Return Date :</label>
            <input type="date" name="returnDate" id="return-id" disabled></input>
            <br>
            <label for="">Entered By :</label>
            <input type="text" name="enteredId" id="enter-by-id" disabled></input>
            <br>
            <label for="">Updated By :</label>
            <input type="text" name="updateId" id="update-by-id" disabled></input>
        </form>

    </div>

    </section>

    <div>
        <input type="search" placeholder="Search by book id" id="searchBar">
    </div>

    <section id="display">

        <div class="displayData">
            <h3>Show Data From Database (Need to fetch data from database Table)</h3>
        </div>

    </section>

    <p id="result"></p>

    <div id="footerDiv">
        <p>Powered by Me</p>
    </div>

    </div>


    <script>
        /* When the user clicks on the button, 
        toggle between hiding and showing the dropdown content */
        function myFunction() {
          document.getElementById("myDropdown").classList.toggle("show");
        }

        function myFunctionRepo() {
          document.getElementById("myDropdownRepo").classList.toggle("show");
        }

        window.onclick = function(event) {
          if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
              var openDropdown = dropdowns[i];
              if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
              }
            }
          }
        }
        
        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
          if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
              var openDropdown = dropdowns[i];
              if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
              }
            }
          }
        }
        </script>
</body>
</html>