<?php
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h1>Your Email Id : $_SESSION[email]</h1>");
} else{
    header('Location: login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Page</title>
    <link rel="stylesheet" href="message.css">

</head>
<body>

    

    <section id="messageBox">
        <div id="title">
            <h2>Send Messaging System</h2>
        </div>
        <div id="messageAndHomeBtn">
            <button id="messageCom">Compose Message</button>
            <button href="mainWindow.php" id="homeBtn">Home</button>
        </div>

        <section id="composeMsgBox">
            <div class="upDiv">
                <label for="">Select To User</label>
                <select name="" id="">
                    <option value=""></option>
                    <option value="">Afia</option>
                    <option value="">Afzal</option>
                    <option value="">Akhter</option>
                    <option value="">Akhlak</option>
                    <option value="">Ali</option>
                </select>
                <div class="sendAllUser">
                    <input type="checkbox">
                </div>
            </div>
            <hr>
            <div class="downDiv">
                <textarea name="textarea" id="textBox" cols="50" rows="6"></textarea>
                <div class="btnTextArea">
                    <button id="sendBtn">Send</button>
                    <button id="resetBtn">Reset</button>
                    <button id="closeBtn">Close</button>
                </div>
            </div>
        </section>

        <div id="parentDiv">
            <div class="leftSide">
                <div class="buttonAll">
                    <button id="unread">Unread</button>
                    <button id="read">Read</button>
                    <button id="all">All</button>
                    <button id="today">Today</button>
                    <button id="outbox">Outbox</button>
                </div>
            </div>
            <div class="rightSide">
                <input type="text" disabled>
                <input type="text" disabled>
            </div>
        </div>
    </section>
    

    <script>
        let homeBtn = document.querySelector("#homeBtn");
        homeBtn.addEventListener('click', () => {
            window.open("mainWindow.php", "_self");
        })

        // composeMsgBox Section
        let messageCom = document.querySelector("#messageCom");
        let composeMsgBox = document.querySelector("#composeMsgBox");
        let closeBtn = document.querySelector("#closeBtn");

        messageCom.addEventListener('click', () => {
            composeMsgBox.style.position = 'fixed';
            composeMsgBox.style.backgroundColor = 'teal';
            composeMsgBox.style.marginLeft = '300px';
            composeMsgBox.style.marginTop = '50px';
            composeMsgBox.style.display = 'block';

        })
        closeBtn.addEventListener('click', () => {
            composeMsgBox.style.display = 'none';
        })
    </script>
</body>
</html>