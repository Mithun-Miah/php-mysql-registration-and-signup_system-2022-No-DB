<?php
// database connection
$connection = mysqli_connect('localhost', 'root', '', 'signup_db');

$msg=$fname=$lname=$dateofbirth=$gender=$email=$password=$confirm_password= "";

if($connection){
    // echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

// select all html form name attribute
if (isset($_POST['registerBtn'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $dateofbirth = $_POST['dateofbirth'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // check duplicate email
    $email_check = "SELECT * FROM registration_table where email = '$email' "; // select database column name and html form input name
    $email_query = mysqli_query($connection, $email_check); // Execute query
    $num_row = mysqli_num_rows($email_query); // check number of rows
    if($num_row>0){
        $msg = "email already exist, please try another email"; // show duplicate email user input
    } else{
        // check password and confirm password
        if($password==$confirm_password){
            $specialChars = preg_match('@[^\w]@', $password); // check password special charecter
            // check password special charecter and password length
            if(!$specialChars || strlen($password) == 8 || strlen($password) < 8){
                $msg = "***Please give a special character and password length more then 8***";

            } else{
                // data insert query working
                $insertData = "INSERT INTO registration_table(first_name,last_name,dateofbirth,gender,email,password,confirm_password) 
                VALUES('$fname','$lname','$dateofbirth','$gender','$email','$password','$confirm_password') ";

                $query = mysqli_query($connection, $insertData);
                if($query){
                    $msg = "Registration Success";
                } else{
                    $msg = "Registration Failed";
                }

            }
        } else{
            echo ("<script>alert('Password and Confirm Password Dose Not Match !')</script>");
        }
        

    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Registration Form</title>
    <link rel="stylesheet" href="registration.css">

    <style>
        .reg_container {
            width: 800px;
            height: 100vh;
            background-color: antiquewhite;
            padding: 10px 10px;
            margin: 10px auto;
            border-radius: 20px;
        }
        .reg_container h3{
            color: blue;
            border: 1px solid green;
            text-align: center;
            padding: 6px;
        }
        .regBtnDiv {
            text-align: start;
        }
        .logLinkDiv {
            margin-top: 10px;
            margin-bottom: 30px;
            text-align: end;
            margin-right: 200px;
        }

    </style>
</head>
<body>

    <div class="reg_container">
        <h1>Registration Form</h1>
        <h3><?php echo $msg;?></h3>
        <form method="POST">
            <label for="">First Name</label>
            <br>
            <input type="text" name="fname" value="<?php echo $fname ?>" require>
            <br><br>
            <label for="">Last Name</label>
            <br>
            <input type="text" name="lname" value="<?php echo $lname ?>" require>
            <br><br>
            <label for="">Date of Birth</label>
            <br>
            <input type="date" name="dateofbirth" value="<?php echo $dateofbirth ?>" require>
            <br><br>
            <label for="">Gender</label>
            <br>
            <input type="text" name="gender" value="<?php echo $gender ?>" require>
            <br><br>
            <label for="">Email</label>
            <br>
            <input type="text" name="email" value="<?php echo $email ?>" require>
            <br><br>
            <label for="">Password</label>
            <br>
            <input type="password" name="password" value="<?php echo $password ?>" require>
            <br><br>
            <label for="">Confirm Password</label>
            <br>
            <input type="password" name="confirm_password" value="<?php echo $confirm_password ?>" require>
            <br><br>
            <div class="regBtnDiv">
            <button id="regBtn" name="registerBtn">Register</button>
            <!-- <a href="login.php" id="logBtn">Login</a> -->
            </div>
        </form>
        <div class="logLinkDiv">
        <a href="login.php" id="logBtn">Login</a>
        </div>
    </div>
    
</body>
</html>